// ===== TARAR MENSWEAR — shared script =====

// ---------- Live store data (fetched from the backend / admin panel) ----------
const API = '/api';

const CATEGORY_ICONS = {
  "Wash & Wear": "&#128085;",
  "Cotton": "&#129513;",
  "Lawn": "&#127800;",
  "Casual Wear": "&#128096;",
  "Formal Wear": "&#128188;",
  "Summer Collection": "&#9728;&#65039;",
  "Winter Collection": "&#10052;&#65039;",
  "Men's Perfumes": "&#128081;",
  "Women's Perfumes": "&#128132;"
};
function categoryIcon(name) {
  return CATEGORY_ICONS[name] || "&#128715;";
}

async function fetchCategories() {
  try {
    const res = await fetch(API + '/categories');
    if (!res.ok) throw new Error('Failed to load categories');
    return await res.json();
  } catch (e) {
    console.error(e);
    return [];
  }
}

async function fetchProducts(params = {}) {
  try {
    const qs = new URLSearchParams(params).toString();
    const res = await fetch(API + '/products' + (qs ? '?' + qs : ''));
    if (!res.ok) throw new Error('Failed to load products');
    return await res.json();
  } catch (e) {
    console.error(e);
    return [];
  }
}

async function fetchProduct(id) {
  try {
    const res = await fetch(API + '/products/' + encodeURIComponent(id));
    if (!res.ok) return null;
    return await res.json();
  } catch (e) {
    console.error(e);
    return null;
  }
}

function renderStars(rating) {
  const r = Math.round(rating || 0);
  return '&#9733;'.repeat(r) + '&#9734;'.repeat(5 - r);
}

function formatPrice(n) {
  return 'Rs. ' + Number(n || 0).toLocaleString('en-PK');
}

function productCardHTML(p) {
  const onSale = p.discountPrice && p.discountPrice > 0 && p.discountPrice < p.price;
  const priceHTML = onSale
    ? `<span class="price">${formatPrice(p.discountPrice)}</span><span class="price-old">${formatPrice(p.price)}</span>`
    : `<span class="price">${formatPrice(p.price)}</span>`;
  const tag = onSale
    ? `<span class="tag sale">-${Math.round(100 - (p.discountPrice / p.price) * 100)}%</span>`
    : (p.featured ? `<span class="tag">New</span>` : '');
  const swatches = (p.colors || []).map(c => `<span class="swatch" style="background:${c};"></span>`).join('');
  const unstitchedBadge = (p.stitching || []).includes('Unstitched')
    ? `<span class="tag" style="background:#3E6B4B;">Unstitched Available</span>` : '';
  return `
    <div class="product-card">
      <a href="product.html?id=${encodeURIComponent(p.id)}" class="product-thumb">Product Image${tag}${unstitchedBadge}
        <button class="wish-btn">&#9825;</button>
      </a>
      <div class="product-info">
        <span class="p-cat">${p.category}</span>
        <h4>${p.name}</h4>
        <div class="stars">${renderStars(p.rating)} <span style="color:#a39a8f; font-size:0.75rem;">(${p.reviewsCount || 0})</span></div>
        <div class="price-row">${priceHTML}</div>
        <div class="swatches">${swatches}</div>
        <div class="product-actions">
          <button class="btn btn-primary add-cart-btn">Add to Cart</button>
          <a href="product.html?id=${encodeURIComponent(p.id)}" class="btn btn-outline">Buy Now</a>
        </div>
      </div>
    </div>`;
}

function catCardHTML(cat, count) {
  return `<a href="shop.html?category=${encodeURIComponent(cat.name)}" class="cat-card" data-icon="${categoryIcon(cat.name)}"><h4>${cat.name}</h4><span>${count} Product${count === 1 ? '' : 's'}</span></a>`;
}

function bindDynamicCardEvents(container) {
  container.querySelectorAll('.wish-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      btn.classList.toggle('active');
      btn.textContent = btn.classList.contains('active') ? '♥' : '♡';
      showToast(btn.classList.contains('active') ? 'Added to wishlist' : 'Removed from wishlist');
    });
  });
  container.querySelectorAll('.add-cart-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      showToast('Added to cart');
    });
  });
}

async function fetchDeals() {
  try {
    const res = await fetch(API + '/deals');
    if (!res.ok) throw new Error('Failed to load deals');
    return await res.json();
  } catch (e) {
    console.error(e);
    return [];
  }
}

function dealCardHTML(deal) {
  const thumbs = deal.products.map(p => `
    <div style="flex:1; text-align:center; border:1px solid #e7e0d4; padding:8px; border-radius:6px; background:#faf8f4;">
      <div style="font-size:0.72rem; font-weight:600; line-height:1.3;">${p.name}</div>
    </div>`).join('<div style="align-self:center; font-weight:700; color:var(--gold, #b8860b);">+</div>');

  const savingsPct = deal.originalTotal > 0 ? Math.round((deal.savings / deal.originalTotal) * 100) : 0;

  return `
    <div class="product-card" style="padding:18px;">
      <span class="tag sale" style="position:static; display:inline-block; margin-bottom:10px;">Bundle Deal${savingsPct > 0 ? ' -' + savingsPct + '%' : ''}</span>
      <h4 style="margin-bottom:10px;">${deal.title}</h4>
      ${deal.description ? `<p style="font-size:0.8rem; color:#8a8074; margin-bottom:12px;">${deal.description}</p>` : ''}
      <div style="display:flex; gap:6px; margin-bottom:14px;">${thumbs}</div>
      <div class="price-row" style="margin-bottom:14px;">
        <span class="price-old">${formatPrice(deal.originalTotal)}</span>
        <span class="price">${formatPrice(deal.dealPrice)}</span>
      </div>
      <a href="checkout.html?deal=${encodeURIComponent(deal.id)}" class="btn btn-gold btn-block">Grab This Deal</a>
    </div>`;
}

// ---------- HOMEPAGE ----------
async function initHomepage() {
  const catGrid = document.getElementById('home-cat-grid');
  const prodGrid = document.getElementById('home-product-grid');
  const dealsGrid = document.getElementById('home-deals-grid');
  const dealsSection = document.getElementById('deals-section');
  if (!catGrid && !prodGrid && !dealsGrid) return;

  const [categories, products] = await Promise.all([fetchCategories(), fetchProducts()]);

  if (catGrid) {
    catGrid.innerHTML = categories.map(cat => {
      const count = products.filter(p => p.category === cat.name).length;
      return catCardHTML(cat, count);
    }).join('');
  }

  if (prodGrid) {
    const featured = products.filter(p => p.featured);
    const list = (featured.length ? featured : products).slice(0, 8);
    prodGrid.innerHTML = list.map(productCardHTML).join('');
    bindDynamicCardEvents(prodGrid);
  }

  if (dealsGrid) {
    const deals = await fetchDeals();
    if (deals.length) {
      dealsGrid.innerHTML = deals.map(dealCardHTML).join('');
      if (dealsSection) dealsSection.style.display = 'block';
    } else if (dealsSection) {
      dealsSection.style.display = 'none';
    }
  }
}

// ---------- SHOP PAGE ----------
async function initShopPage() {
  const filterBox = document.getElementById('shop-cat-filters');
  const grid = document.getElementById('shop-grid');
  const countLabel = document.getElementById('shop-count-label');
  if (!grid) return;

  const params = new URLSearchParams(window.location.search);
  const preselectedCategory = params.get('category');

  const [categories, allProducts] = await Promise.all([fetchCategories(), fetchProducts()]);

  if (filterBox) {
    filterBox.innerHTML = categories.map(cat => `
      <label><input type="checkbox" value="${cat.name}" ${cat.name === preselectedCategory ? 'checked' : ''}> ${cat.name}</label>
    `).join('') + `
      <h4>Stitching</h4>
      <label><input type="checkbox" id="filter-unstitched" value="unstitched"> Unstitched Available</label>
    `;
  }

  function applyFilters() {
    const checked = filterBox
      ? Array.from(filterBox.querySelectorAll('input[type=checkbox]:not(#filter-unstitched)'))
          .filter(c => c.checked).map(c => c.value)
      : [];
    const unstitchedOnly = filterBox && filterBox.querySelector('#filter-unstitched')?.checked;

    let list = allProducts;
    if (checked.length) list = list.filter(p => checked.includes(p.category));
    if (unstitchedOnly) list = list.filter(p => (p.stitching || []).includes('Unstitched'));

    grid.innerHTML = list.map(productCardHTML).join('');
    bindDynamicCardEvents(grid);
    if (countLabel) countLabel.textContent = `Showing ${list.length} of ${allProducts.length} products`;
  }

  if (filterBox) {
    filterBox.addEventListener('change', applyFilters);
  }
  applyFilters();
}

// ---------- PRODUCT DETAIL PAGE ----------
async function initProductPage() {
  const infoBox = document.getElementById('pd-dynamic');
  if (!infoBox) return;

  const params = new URLSearchParams(window.location.search);
  const id = params.get('id');
  const product = id ? await fetchProduct(id) : null;

  if (!product) {
    infoBox.innerHTML = '<p>Product not found. <a href="shop.html">Back to Shop</a></p>';
    return;
  }

  document.title = product.name + ' — Tarar Menswear';

  const onSale = product.discountPrice && product.discountPrice > 0 && product.discountPrice < product.price;
  const priceHTML = onSale
    ? `<span class="price">${formatPrice(product.discountPrice)}</span><span class="price-old">${formatPrice(product.price)}</span>`
    : `<span class="price">${formatPrice(product.price)}</span>`;

  const colorsHTML = (product.colors || []).map((c, i) => `<span class="swatch" style="width:26px;height:26px;background:${c}; ${i === 0 ? 'border:2px solid var(--gold);' : ''}"></span>`).join('');

  const sizeHTML = (product.sizes && product.sizes.length) ? `
    <div class="option-group">
      <h5>Size</h5>
      <div class="size-row">
        ${product.sizes.map((s, i) => `<div class="size-box${i === 0 ? ' active' : ''}">${s}</div>`).join('')}
      </div>
    </div>` : '';

  const stitchingHTML = (product.stitching && product.stitching.length) ? `
    <div class="option-group">
      <h5>Stitching</h5>
      <div class="size-row">
        ${product.stitching.map((s, i) => `<div class="size-box${i === 0 ? ' active' : ''}">${s}</div>`).join('')}
      </div>
    </div>` : '';

  document.getElementById('pd-breadcrumb-cat').textContent = product.category;
  document.getElementById('pd-breadcrumb-name').textContent = product.name;
  document.getElementById('pd-page-title').textContent = product.name;

  infoBox.innerHTML = `
    <span class="p-cat">${product.category} · SKU: ${product.id.toUpperCase()}</span>
    <h1>${product.name}</h1>
    <div class="stars">${renderStars(product.rating)} <span style="color:#a39a8f; font-size:0.8rem;">${(product.rating || 0)} (${product.reviewsCount || 0} Reviews)</span></div>
    <div class="price-row">${priceHTML}</div>
    <p class="pd-desc">${product.description || ''}</p>
    <div class="stock-status">&#9679; ${product.status === 'in_stock' ? 'In Stock — Ready to Ship' : 'Out of Stock'}</div>
    ${colorsHTML ? `<div class="option-group"><h5>Color</h5><div class="swatches">${colorsHTML}</div></div>` : ''}
    ${sizeHTML}
    ${stitchingHTML}
    <div class="option-group">
      <h5>Quantity</h5>
      <div class="qty-row">
        <div class="qty-box">
          <button class="qty-minus">−</button>
          <input type="text" value="1">
          <button class="qty-plus">+</button>
        </div>
      </div>
    </div>
    <div class="pd-actions">
      <button class="btn btn-primary add-cart-btn" style="flex:1;">Add to Cart</button>
      <a href="checkout.html" class="btn btn-gold" style="flex:1;">Buy Now</a>
      <button class="wish-btn" style="position:static; width:48px; height:48px; border:1px solid #d8cdbd; background:none; border-radius:0;">&#9825;</button>
    </div>
    <div class="tabs">
      <div class="tab-head">
        <button class="active" data-tab="tab-desc">Description</button>
        <button data-tab="tab-fabric">Fabric Details</button>
        <button data-tab="tab-reviews">Reviews (${product.reviewsCount || 0})</button>
      </div>
      <div class="tab-panel active" id="tab-desc"><p>${product.description || ''}</p></div>
      <div class="tab-panel" id="tab-fabric"><p>${product.fabric || 'Details not available.'}</p></div>
      <div class="tab-panel" id="tab-reviews"><p>No written reviews yet — be the first to review this product.</p></div>
    </div>
  `;

  bindDynamicCardEvents(infoBox);
  bindProductDetailInteractivity();

  // Related products (same category, excluding current)
  const relatedGrid = document.getElementById('pd-related-grid');
  if (relatedGrid) {
    const related = (await fetchProducts({ category: product.category })).filter(p => p.id !== product.id).slice(0, 4);
    relatedGrid.innerHTML = related.map(productCardHTML).join('');
    bindDynamicCardEvents(relatedGrid);
  }
}

function bindProductDetailInteractivity() {
  document.querySelectorAll('.size-box').forEach(box => {
    box.addEventListener('click', () => {
      box.parentElement.querySelectorAll('.size-box').forEach(b => b.classList.remove('active'));
      box.classList.add('active');
    });
  });
  document.querySelectorAll('.tab-head button').forEach(btn => {
    btn.addEventListener('click', () => {
      const target = btn.dataset.tab;
      btn.parentElement.querySelectorAll('button').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
      document.getElementById(target)?.classList.add('active');
    });
  });
  document.querySelectorAll('.qty-box').forEach(box => {
    const input = box.querySelector('input');
    box.querySelector('.qty-minus')?.addEventListener('click', () => {
      let v = parseInt(input.value) || 1;
      if (v > 1) input.value = v - 1;
    });
    box.querySelector('.qty-plus')?.addEventListener('click', () => {
      let v = parseInt(input.value) || 1;
      input.value = v + 1;
    });
  });
}

document.addEventListener('DOMContentLoaded', () => {
  initHomepage();
  initShopPage();
  initProductPage();
});

// Mobile nav toggle
document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.main-nav');
  if (toggle && nav) {
    toggle.addEventListener('click', () => nav.classList.toggle('open'));
  }

  // Promo popup (shows once per page load, after short delay)
  const promo = document.querySelector('.promo-modal');
  if (promo) {
    setTimeout(() => promo.classList.add('show'), 2500);
    const closeBtn = promo.querySelector('.close-x');
    if (closeBtn) closeBtn.addEventListener('click', () => promo.classList.remove('show'));
    promo.addEventListener('click', (e) => { if (e.target === promo) promo.classList.remove('show'); });
  }

  // Product detail: thumbnail switch
  document.querySelectorAll('.pd-thumbs div').forEach(thumb => {
    thumb.addEventListener('click', () => {
      document.querySelectorAll('.pd-thumbs div').forEach(t => t.classList.remove('active'));
      thumb.classList.add('active');
    });
  });

  // Product detail: size select
  document.querySelectorAll('.size-box').forEach(box => {
    box.addEventListener('click', () => {
      box.parentElement.querySelectorAll('.size-box').forEach(b => b.classList.remove('active'));
      box.classList.add('active');
    });
  });

  // Product detail: tabs
  document.querySelectorAll('.tab-head button').forEach(btn => {
    btn.addEventListener('click', () => {
      const target = btn.dataset.tab;
      btn.parentElement.querySelectorAll('button').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
      document.getElementById(target)?.classList.add('active');
    });
  });

  // Quantity stepper
  document.querySelectorAll('.qty-box').forEach(box => {
    const input = box.querySelector('input');
    box.querySelector('.qty-minus')?.addEventListener('click', () => {
      let v = parseInt(input.value) || 1;
      if (v > 1) input.value = v - 1;
    });
    box.querySelector('.qty-plus')?.addEventListener('click', () => {
      let v = parseInt(input.value) || 1;
      input.value = v + 1;
    });
  });

  // Wishlist heart toggle (demo, in-memory only)
  document.querySelectorAll('.wish-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      btn.classList.toggle('active');
      btn.textContent = btn.classList.contains('active') ? '♥' : '♡';
      showToast(btn.classList.contains('active') ? 'Added to wishlist' : 'Removed from wishlist');
    });
  });

  // Add to cart demo buttons
  document.querySelectorAll('.add-cart-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      showToast('Added to cart');
    });
  });

  // Cart quantity change recalculates row + summary (demo, static numbers on cart.html)
  document.querySelectorAll('.cart-table .qty-box input').forEach(input => {
    input.addEventListener('change', () => showToast('Cart updated'));
  });

  // Checkout payment method select
  document.querySelectorAll('.pay-option').forEach(opt => {
    opt.addEventListener('click', () => {
      document.querySelectorAll('.pay-option').forEach(o => o.classList.remove('active'));
      opt.classList.add('active');
    });
  });

  // Newsletter / contact form demo submit
  document.querySelectorAll('form[data-demo-form]').forEach(form => {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      showToast('Thank you! We will get back to you soon.');
      form.reset();
    });
  });
});

function showToast(msg) {
  let toast = document.querySelector('.toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.className = 'toast';
    document.body.appendChild(toast);
  }
  toast.textContent = msg;
  toast.classList.add('show');
  clearTimeout(window._toastTimer);
  window._toastTimer = setTimeout(() => toast.classList.remove('show'), 2200);
}
