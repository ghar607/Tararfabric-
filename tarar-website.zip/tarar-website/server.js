const express = require('express');
const cors = require('cors');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { v4: uuidv4 } = require('uuid');

const app = express();
const PORT = 8080;
const DB_FILE = path.join(__dirname, 'db.json');
const UPLOADS_DIR = path.join(__dirname, 'uploads');

if (!fs.existsSync(UPLOADS_DIR)) fs.mkdirSync(UPLOADS_DIR, { recursive: true });

app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(UPLOADS_DIR));
app.use('/admin', express.static(path.join(__dirname, 'admin')));
app.use('/', express.static(path.join(__dirname, 'public')));

// ---------- DB helpers ----------
function readDB() {
  const db = JSON.parse(fs.readFileSync(DB_FILE, 'utf-8'));
  if (!db.customers) db.customers = [];
  if (!db.customerSessions) db.customerSessions = [];
  if (!db.deals) db.deals = [];
  return db;
}
function writeDB(data) {
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
}

// ---------- Password hashing ----------
function hashPassword(password, salt) {
  salt = salt || crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return { salt, hash };
}
function verifyPassword(password, salt, hash) {
  const check = crypto.scryptSync(password, salt, 64).toString('hex');
  const a = Buffer.from(check, 'hex');
  const b = Buffer.from(hash, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

// ---------- Multer (image upload) ----------
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOADS_DIR),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, uuidv4() + ext);
  }
});
const upload = multer({ storage });

// ---------- Auth middleware ----------
function requireAuth(req, res, next) {
  const authHeader = req.headers.authorization || '';
  const token = authHeader.replace('Bearer ', '').trim();
  const db = readDB();
  const valid = db.sessions.includes(token);
  if (!token || !valid) {
    return res.status(401).json({ error: 'Unauthorized. Please login again.' });
  }
  next();
}

// ---------- Customer auth middleware ----------
function requireCustomerAuth(req, res, next) {
  const authHeader = req.headers.authorization || '';
  const token = authHeader.replace('Bearer ', '').trim();
  const db = readDB();
  const session = db.customerSessions.find(s => s.token === token);
  if (!token || !session) {
    return res.status(401).json({ error: 'Please login to continue' });
  }
  req.customerId = session.customerId;
  next();
}

// ================= CUSTOMER AUTH =================
app.post('/api/auth/register', (req, res) => {
  const { name, phone, email, password } = req.body || {};
  if (!name || !phone || !password) {
    return res.status(400).json({ error: 'Name, mobile number and password are required' });
  }
  if (password.length < 4) {
    return res.status(400).json({ error: 'Password must be at least 4 characters' });
  }
  const db = readDB();
  const exists = db.customers.find(c => c.phone === phone || (email && c.email && c.email === email));
  if (exists) {
    return res.status(400).json({ error: 'An account with this mobile number or email already exists' });
  }
  const { salt, hash } = hashPassword(password);
  const customer = {
    id: 'cust-' + uuidv4(),
    name,
    phone,
    email: email || '',
    passwordSalt: salt,
    passwordHash: hash,
    createdAt: new Date().toISOString()
  };
  db.customers.push(customer);
  const token = crypto.randomBytes(24).toString('hex');
  db.customerSessions.push({ token, customerId: customer.id });
  writeDB(db);
  res.json({ token, customer: { id: customer.id, name: customer.name, phone: customer.phone, email: customer.email } });
});

app.post('/api/auth/login', (req, res) => {
  const { identifier, password } = req.body || {};
  if (!identifier || !password) {
    return res.status(400).json({ error: 'Email/mobile number and password are required' });
  }
  const db = readDB();
  const customer = db.customers.find(c => c.phone === identifier || (c.email && c.email === identifier));
  if (!customer || !verifyPassword(password, customer.passwordSalt, customer.passwordHash)) {
    return res.status(401).json({ error: 'Invalid login details' });
  }
  const token = crypto.randomBytes(24).toString('hex');
  db.customerSessions.push({ token, customerId: customer.id });
  writeDB(db);
  res.json({ token, customer: { id: customer.id, name: customer.name, phone: customer.phone, email: customer.email } });
});

app.post('/api/auth/logout', requireCustomerAuth, (req, res) => {
  const token = req.headers.authorization.replace('Bearer ', '').trim();
  const db = readDB();
  db.customerSessions = db.customerSessions.filter(s => s.token !== token);
  writeDB(db);
  res.json({ success: true });
});

app.get('/api/auth/me', requireCustomerAuth, (req, res) => {
  const db = readDB();
  const customer = db.customers.find(c => c.id === req.customerId);
  if (!customer) return res.status(404).json({ error: 'Account not found' });
  res.json({ id: customer.id, name: customer.name, phone: customer.phone, email: customer.email, createdAt: customer.createdAt });
});

// Customer's own order history
app.get('/api/my/orders', requireCustomerAuth, (req, res) => {
  const db = readDB();
  const customer = db.customers.find(c => c.id === req.customerId);
  const orders = db.orders.filter(o => o.customerId === req.customerId || (customer && o.customer.phone === customer.phone));
  res.json(orders);
});

// Customer's own order stats
app.get('/api/my/stats', requireCustomerAuth, (req, res) => {
  const db = readDB();
  const customer = db.customers.find(c => c.id === req.customerId);
  const orders = db.orders.filter(o => o.customerId === req.customerId || (customer && o.customer.phone === customer.phone));
  res.json({
    totalOrders: orders.length,
    pending: orders.filter(o => o.status === 'pending').length,
    accepted: orders.filter(o => o.status === 'accepted').length,
    dispatched: orders.filter(o => o.status === 'dispatched').length,
    delivered: orders.filter(o => o.status === 'delivered').length,
    cancelled: orders.filter(o => o.status === 'cancelled').length,
    totalSpent: orders.filter(o => o.status !== 'cancelled').reduce((sum, o) => sum + (o.total || 0), 0)
  });
});

// ================= ADMIN AUTH =================
app.post('/api/admin/login', (req, res) => {
  const { username, password } = req.body;
  const db = readDB();
  if (username === db.admin.username && password === db.admin.password) {
    const token = crypto.randomBytes(24).toString('hex');
    db.sessions.push(token);
    writeDB(db);
    return res.json({ token });
  }
  res.status(401).json({ error: 'Invalid username or password' });
});

app.post('/api/admin/logout', requireAuth, (req, res) => {
  const token = req.headers.authorization.replace('Bearer ', '').trim();
  const db = readDB();
  db.sessions = db.sessions.filter(s => s !== token);
  writeDB(db);
  res.json({ success: true });
});

app.post('/api/admin/change-password', requireAuth, (req, res) => {
  const { currentPassword, newPassword } = req.body;
  const db = readDB();
  if (currentPassword !== db.admin.password) {
    return res.status(400).json({ error: 'Current password is incorrect' });
  }
  db.admin.password = newPassword;
  writeDB(db);
  res.json({ success: true });
});

// ================= SETTINGS =================
app.get('/api/settings', (req, res) => {
  res.json(readDB().settings);
});
app.put('/api/admin/settings', requireAuth, (req, res) => {
  const db = readDB();
  db.settings = { ...db.settings, ...req.body };
  writeDB(db);
  res.json(db.settings);
});

// ================= CATEGORIES =================
app.get('/api/categories', (req, res) => {
  res.json(readDB().categories);
});
app.post('/api/admin/categories', requireAuth, (req, res) => {
  const db = readDB();
  const cat = { id: 'cat-' + uuidv4(), name: req.body.name };
  db.categories.push(cat);
  writeDB(db);
  res.json(cat);
});
app.put('/api/admin/categories/:id', requireAuth, (req, res) => {
  const db = readDB();
  const cat = db.categories.find(c => c.id === req.params.id);
  if (!cat) return res.status(404).json({ error: 'Category not found' });
  cat.name = req.body.name;
  writeDB(db);
  res.json(cat);
});
app.delete('/api/admin/categories/:id', requireAuth, (req, res) => {
  const db = readDB();
  db.categories = db.categories.filter(c => c.id !== req.params.id);
  writeDB(db);
  res.json({ success: true });
});

// ================= PRODUCTS =================
app.get('/api/products', (req, res) => {
  const db = readDB();
  let list = db.products;
  const { category, featured, search, gender, unstitched } = req.query;
  if (category) list = list.filter(p => p.category === category);
  if (featured) list = list.filter(p => p.featured);
  if (search) list = list.filter(p => p.name.toLowerCase().includes(search.toLowerCase()));
  if (gender) list = list.filter(p => p.gender === gender || p.gender === 'unisex');
  if (unstitched) list = list.filter(p => (p.stitching || []).includes('Unstitched'));
  res.json(list);
});

app.get('/api/products/:id', (req, res) => {
  const db = readDB();
  const product = db.products.find(p => p.id === req.params.id);
  if (!product) return res.status(404).json({ error: 'Product not found' });
  res.json(product);
});

app.post('/api/admin/products', requireAuth, upload.array('images', 6), (req, res) => {
  const db = readDB();
  const body = req.body;
  const newImages = (req.files || []).map(f => '/uploads/' + f.filename);
  const product = {
    id: 'prod-' + uuidv4(),
    name: body.name,
    category: body.category,
    price: Number(body.price) || 0,
    discountPrice: Number(body.discountPrice) || 0,
    sizes: body.sizes ? JSON.parse(body.sizes) : [],
    colors: body.colors ? JSON.parse(body.colors) : [],
    gender: body.gender || 'unisex',
    stitching: body.stitching ? JSON.parse(body.stitching) : [],
    stock: Number(body.stock) || 0,
    status: Number(body.stock) > 0 ? 'in_stock' : 'out_of_stock',
    featured: body.featured === 'true' || body.featured === true,
    description: body.description || '',
    fabric: body.fabric || '',
    images: newImages,
    rating: 0,
    reviewsCount: 0
  };
  db.products.push(product);
  writeDB(db);
  res.json(product);
});

app.put('/api/admin/products/:id', requireAuth, upload.array('images', 6), (req, res) => {
  const db = readDB();
  const product = db.products.find(p => p.id === req.params.id);
  if (!product) return res.status(404).json({ error: 'Product not found' });
  const body = req.body;

  if (body.name !== undefined) product.name = body.name;
  if (body.category !== undefined) product.category = body.category;
  if (body.price !== undefined) product.price = Number(body.price);
  if (body.discountPrice !== undefined) product.discountPrice = Number(body.discountPrice);
  if (body.sizes !== undefined) product.sizes = JSON.parse(body.sizes);
  if (body.colors !== undefined) product.colors = JSON.parse(body.colors);
  if (body.gender !== undefined) product.gender = body.gender;
  if (body.stitching !== undefined) product.stitching = JSON.parse(body.stitching);
  if (body.stock !== undefined) {
    product.stock = Number(body.stock);
    product.status = product.stock > 0 ? 'in_stock' : 'out_of_stock';
  }
  if (body.featured !== undefined) product.featured = body.featured === 'true' || body.featured === true;
  if (body.description !== undefined) product.description = body.description;
  if (body.fabric !== undefined) product.fabric = body.fabric;

  if (body.keepImages !== undefined) {
    try { product.images = JSON.parse(body.keepImages); } catch (e) {}
  }
  const newImages = (req.files || []).map(f => '/uploads/' + f.filename);
  product.images = [...(product.images || []), ...newImages];

  writeDB(db);
  res.json(product);
});

app.delete('/api/admin/products/:id', requireAuth, (req, res) => {
  const db = readDB();
  db.products = db.products.filter(p => p.id !== req.params.id);
  writeDB(db);
  res.json({ success: true });
});

// ================= ORDERS =================
// Customer places order (public, no auth)
app.post('/api/orders', (req, res) => {
  const db = readDB();
  const body = req.body;

  // If the customer is logged in, link this order to their account automatically
  let customerId = null;
  const authHeader = req.headers.authorization || '';
  const token = authHeader.replace('Bearer ', '').trim();
  if (token) {
    const session = db.customerSessions.find(s => s.token === token);
    if (session) customerId = session.customerId;
  }

  const order = {
    id: 'TRR-' + Math.floor(1000 + Math.random() * 9000),
    customerId,
    customer: {
      name: body.customer?.name || '',
      phone: body.customer?.phone || '',
      email: body.customer?.email || '',
      address: body.customer?.address || '',
      city: body.customer?.city || '',
      province: body.customer?.province || ''
    },
    items: body.items || [],
    subtotal: body.subtotal || 0,
    shipping: body.shipping || 0,
    total: body.total || 0,
    paymentMethod: body.paymentMethod || 'COD',
    transactionId: body.transactionId || '',
    paymentVerified: body.paymentMethod === 'COD' ? null : false,
    status: 'pending',
    courierCompany: '',
    trackingNumber: '',
    createdAt: new Date().toISOString()
  };
  db.orders.unshift(order);
  writeDB(db);
  res.json(order);
});

app.get('/api/admin/orders', requireAuth, (req, res) => {
  const db = readDB();
  res.json(db.orders);
});

app.get('/api/admin/orders/:id', requireAuth, (req, res) => {
  const db = readDB();
  const order = db.orders.find(o => o.id === req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found' });
  res.json(order);
});

// Public order tracking — customer provides order id + phone number, no login required
app.get('/api/track', (req, res) => {
  const { orderId, phone } = req.query;
  if (!orderId || !phone) return res.status(400).json({ error: 'orderId and phone are required' });
  const db = readDB();
  const order = db.orders.find(o => o.id === orderId && o.customer.phone === phone);
  if (!order) return res.status(404).json({ error: 'No matching order found' });
  res.json({
    id: order.id,
    status: order.status,
    courierCompany: order.courierCompany || '',
    trackingNumber: order.trackingNumber || '',
    createdAt: order.createdAt
  });
});

// Update order: status, transaction id, verify payment (green/red tick)
app.put('/api/admin/orders/:id', requireAuth, (req, res) => {
  const db = readDB();
  const order = db.orders.find(o => o.id === req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found' });

  const { status, transactionId, paymentVerified, courierCompany, trackingNumber } = req.body;
  if (status !== undefined) order.status = status;
  if (transactionId !== undefined) order.transactionId = transactionId;
  if (paymentVerified !== undefined) order.paymentVerified = paymentVerified;
  if (courierCompany !== undefined) order.courierCompany = courierCompany;
  if (trackingNumber !== undefined) order.trackingNumber = trackingNumber;

  writeDB(db);
  res.json(order);
});

app.delete('/api/admin/orders/:id', requireAuth, (req, res) => {
  const db = readDB();
  db.orders = db.orders.filter(o => o.id !== req.params.id);
  writeDB(db);
  res.json({ success: true });
});

// ================= DEALS (bundle 3 products into one offer) =================
function enrichDeal(db, deal) {
  const products = deal.productIds.map(id => db.products.find(p => p.id === id)).filter(Boolean);
  const originalTotal = products.reduce((sum, p) => sum + (p.discountPrice > 0 ? p.discountPrice : p.price), 0);
  return { ...deal, products, originalTotal, savings: Math.max(0, originalTotal - deal.dealPrice) };
}

// Public — only launched (active) deals
app.get('/api/deals', (req, res) => {
  const db = readDB();
  const active = db.deals.filter(d => d.active);
  res.json(active.map(d => enrichDeal(db, d)));
});

app.get('/api/deals/:id', (req, res) => {
  const db = readDB();
  const deal = db.deals.find(d => d.id === req.params.id);
  if (!deal || !deal.active) return res.status(404).json({ error: 'Deal not found' });
  res.json(enrichDeal(db, deal));
});

// Admin — manage all deals
app.get('/api/admin/deals', requireAuth, (req, res) => {
  const db = readDB();
  res.json(db.deals.map(d => enrichDeal(db, d)));
});

app.post('/api/admin/deals', requireAuth, (req, res) => {
  const db = readDB();
  const { title, description, productIds, dealPrice, active } = req.body || {};
  const ids = Array.isArray(productIds) ? productIds.filter(Boolean) : [];
  if (!title || ids.length !== 3) {
    return res.status(400).json({ error: 'Deal title and exactly 3 products are required' });
  }
  const validProducts = ids.filter(id => db.products.some(p => p.id === id));
  if (validProducts.length !== 3) {
    return res.status(400).json({ error: 'One or more selected products were not found' });
  }
  const deal = {
    id: 'deal-' + uuidv4(),
    title,
    description: description || '',
    productIds: ids,
    dealPrice: Number(dealPrice) || 0,
    active: active !== undefined ? !!active : true,
    createdAt: new Date().toISOString()
  };
  db.deals.unshift(deal);
  writeDB(db);
  res.json(enrichDeal(db, deal));
});

app.put('/api/admin/deals/:id', requireAuth, (req, res) => {
  const db = readDB();
  const deal = db.deals.find(d => d.id === req.params.id);
  if (!deal) return res.status(404).json({ error: 'Deal not found' });
  const { title, description, productIds, dealPrice, active } = req.body || {};
  if (title !== undefined) deal.title = title;
  if (description !== undefined) deal.description = description;
  if (productIds !== undefined) {
    const ids = Array.isArray(productIds) ? productIds.filter(Boolean) : [];
    if (ids.length !== 3) return res.status(400).json({ error: 'Exactly 3 products are required' });
    deal.productIds = ids;
  }
  if (dealPrice !== undefined) deal.dealPrice = Number(dealPrice) || 0;
  if (active !== undefined) deal.active = !!active;
  writeDB(db);
  res.json(enrichDeal(db, deal));
});

app.delete('/api/admin/deals/:id', requireAuth, (req, res) => {
  const db = readDB();
  db.deals = db.deals.filter(d => d.id !== req.params.id);
  writeDB(db);
  res.json({ success: true });
});

// ================= ACTION REMINDERS =================
app.get('/api/admin/reminders', requireAuth, (req, res) => {
  const db = readDB();
  const toDispatch = db.orders.filter(o => o.status === 'accepted');
  const toDeliver = db.orders.filter(o => o.status === 'dispatched');
  res.json({ toDispatch, toDeliver, count: toDispatch.length + toDeliver.length });
});

// ================= DASHBOARD =================
app.get('/api/admin/dashboard', requireAuth, (req, res) => {
  const db = readDB();
  const totalRevenue = db.orders
    .filter(o => o.status !== 'cancelled')
    .reduce((sum, o) => sum + (o.total || 0), 0);
  const lowStock = db.products.filter(p => p.stock <= 5);
  res.json({
    totalOrders: db.orders.length,
    pendingOrders: db.orders.filter(o => o.status === 'pending').length,
    unverifiedPayments: db.orders.filter(o => o.paymentVerified === false).length,
    totalRevenue,
    totalProducts: db.products.length,
    totalCustomers: new Set(db.orders.map(o => o.customer.phone)).size,
    lowStock
  });
});

app.listen(PORT, () => {
  console.log('==========================================');
  console.log('  Tarar Menswear Backend Running!');
  console.log('  Store API:   http://127.0.0.1:' + PORT + '/api');
  console.log('  Admin Panel: http://127.0.0.1:' + PORT + '/admin/login.html');
  console.log('  Default Login -> username: admin | password: tarar123');
  console.log('==========================================');
});
