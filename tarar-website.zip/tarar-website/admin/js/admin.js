const API = '/api';

function getToken() {
  return localStorage.getItem('tarar_admin_token');
}
function requireLogin() {
  if (!getToken()) window.location.href = '/admin/login.html';
  else injectReminderBell();
}

// ---------- Action reminders (payment accepted -> dispatch, dispatched -> delivery) ----------
function injectReminderBell() {
  const topbar = document.querySelector('.topbar');
  if (!topbar || topbar.querySelector('.reminder-bell')) return;

  const bell = document.createElement('a');
  bell.href = 'orders.html';
  bell.className = 'reminder-bell';
  bell.title = 'No pending actions';
  bell.style.cssText = 'position:relative; margin-right:16px; font-size:1.35rem; text-decoration:none; cursor:pointer; line-height:1;';
  bell.innerHTML = '&#128276;<span class="reminder-badge" style="display:none; position:absolute; top:-8px; right:-12px; background:#c0392b; color:#fff; font-size:0.65rem; border-radius:10px; padding:1px 6px; font-weight:700;"></span>';

  const logoutBtn = topbar.querySelector('.logout-btn');
  if (logoutBtn) topbar.insertBefore(bell, logoutBtn);
  else topbar.appendChild(bell);

  async function refreshReminders() {
    const data = await apiGet('/admin/reminders');
    if (!data) return;
    const badge = bell.querySelector('.reminder-badge');
    const count = data.count || 0;
    if (count > 0) {
      badge.textContent = count;
      badge.style.display = 'inline-block';
      bell.title = `${data.toDispatch.length} order(s) waiting to be dispatched, ${data.toDeliver.length} waiting delivery confirmation`;
    } else {
      badge.style.display = 'none';
      bell.title = 'No pending actions';
    }
  }
  refreshReminders();
  setInterval(refreshReminders, 20000);
}
function logout() {
  fetch(API + '/admin/logout', {
    method: 'POST',
    headers: { Authorization: 'Bearer ' + getToken() }
  }).finally(() => {
    localStorage.removeItem('tarar_admin_token');
    window.location.href = '/admin/login.html';
  });
}

async function apiGet(path) {
  const res = await fetch(API + path, {
    headers: { Authorization: 'Bearer ' + getToken() }
  });
  if (res.status === 401) { localStorage.removeItem('tarar_admin_token'); window.location.href = '/admin/login.html'; return; }
  return res.json();
}
async function apiJSON(path, method, body) {
  const res = await fetch(API + path, {
    method,
    headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + getToken() },
    body: JSON.stringify(body)
  });
  if (res.status === 401) { localStorage.removeItem('tarar_admin_token'); window.location.href = '/admin/login.html'; return; }
  return res.json();
}
async function apiForm(path, method, formData) {
  const res = await fetch(API + path, {
    method,
    headers: { Authorization: 'Bearer ' + getToken() },
    body: formData
  });
  if (res.status === 401) { localStorage.removeItem('tarar_admin_token'); window.location.href = '/admin/login.html'; return; }
  return res.json();
}

function showToast(msg) {
  let t = document.querySelector('.toast');
  if (!t) { t = document.createElement('div'); t.className = 'toast'; document.body.appendChild(t); }
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(window._toastTimer);
  window._toastTimer = setTimeout(() => t.classList.remove('show'), 2200);
}

function fmtMoney(n) {
  return 'Rs. ' + (Number(n) || 0).toLocaleString();
}
function fmtDate(iso) {
  const d = new Date(iso);
  return d.toLocaleDateString() + ' ' + d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}
